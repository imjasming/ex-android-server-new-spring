create trigger increase_num
  after INSERT
  on s
  for each row
  update class set studentNumber = studentNumber+1 where NEW.classno=class.classno;

