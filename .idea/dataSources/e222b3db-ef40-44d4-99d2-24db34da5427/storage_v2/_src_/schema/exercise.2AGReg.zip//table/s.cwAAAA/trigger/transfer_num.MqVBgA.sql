create trigger transfer_num
  after UPDATE
  on s
  for each row
begin
update class set studentNumber=studentNumber-1 where OLD.classno=class.classno;
update class set studentNumber=studentNumber+1 where NEW.classno=class.classno;
end;

