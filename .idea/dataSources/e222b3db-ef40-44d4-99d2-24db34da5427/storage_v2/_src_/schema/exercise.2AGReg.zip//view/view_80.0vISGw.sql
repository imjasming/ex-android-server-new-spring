create view view_80 as
select `exercise`.`sc`.`sno` AS `sno`,`exercise`.`sc`.`cno` AS `cno`,`exercise`.`sc`.`grade` AS `grade`
from `exercise`.`sc`
where (`exercise`.`sc`.`grade` > 80);

