create trigger stop_lowwer_grade
  before UPDATE
  on sc
  for each row
begin
if NEW.grade<OLD.grade then
set NEW.grade=OLD.grade;
end if;
end;

