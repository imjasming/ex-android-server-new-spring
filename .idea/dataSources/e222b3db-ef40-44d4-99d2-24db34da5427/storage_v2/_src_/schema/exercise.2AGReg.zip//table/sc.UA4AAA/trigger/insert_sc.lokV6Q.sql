create trigger insert_sc
  before INSERT
  on sc
  for each row
begin
if NEW.sno not in (select sno from s) then
insert into s(sno,sname,sex,birthday,classno) values(NEW.sno,NULL,NULL,NULL,NULL);
end if;
end;

